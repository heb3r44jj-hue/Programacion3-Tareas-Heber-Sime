package model;

import java.io.Serializable;

public class vehiculo  implements Serializable {

    private static final long serialVersionUID = 1L;

    private String placa ;
    private String modelo ;
    private String tipo  ;
    private int velocidadMax;
    private int precio;

    public vehiculo (String placa, String  modelo , String tipo , int velocidadMax, int precio) {
        this.placa = placa;
        this.modelo = modelo ;
        this.tipo = tipo ;
        this.velocidadMax = precio;
        this.precio = precio;
    }

    public String getplaca() {
        return placa;
    }

    public String getmodelo() {
        return modelo;
    }

    public String gettipo() {
        return tipo;
    }

    public int getvelocidadMax() {
        return velocidadMax; 
    }
    
    public int getprecio()  {
        return precio;
    }

    public void setplaca(String placa) {
        this.placa = placa;
    }

    public void setmodelo(String modelo) {
        this.modelo = modelo; 
    }
    
    public void settipo(String tipo){
        this.tipo = tipo;
    }
    public void setPrecio(int  precio) {
        this.precio = precio;
    }
    public void setvelocidadMax(int velocidadMax) {
        this.velocidadMax = velocidadMax;
    }

    public String toLinea() {
        return placa+ ";" + modelo + ";" + tipo + ";" + precio + ";" + velocidadMax;
    } 
    

}
